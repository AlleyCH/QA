﻿using System;

namespace TDDLab_AlleyChaggar
{
    public class Rooter
    {
        public double SquareRoot(double input)
        {
            double result = input;
            double previousResult = -input;
            if (input <= 0.0)
            {
                throw new ArgumentOutOfRangeException();
            }
            while (Math.Abs(previousResult - result) > result / 1000)
            {
                previousResult = result;
                result = result - (result * result - input) / (2 * result);
            }
            return result;
        }

    }
}